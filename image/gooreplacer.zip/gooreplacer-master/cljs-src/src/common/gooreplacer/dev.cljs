(ns gooreplacer.dev)

(enable-console-print!)
